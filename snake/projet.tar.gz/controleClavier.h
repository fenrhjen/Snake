#ifndef CONTROLECLAVIER_H
#define CONTROLECLAVIER_H
#include "constantes.h"
void GestionTouche(int snake[TAILLE_SNAKE][2],int direction[2], int* done);
#endif
